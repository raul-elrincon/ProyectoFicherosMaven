package com.ejemplo.maventaskade;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "empleados")
public class EmpleadoWrapper implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<Empleado> empleados;

    public EmpleadoWrapper() {
    }

    public EmpleadoWrapper(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    @XmlElement(name = "empleado")
    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
}
