package com.ejemplo.maventaskade;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Empleado {

    private String Nombre;
    private String PrimerApellido;
    private String SegundoApellido;
    private String PuestoDeTrabajo;
    private int Sueldo;
    private int Edad;

    // Constructor sin parámetros (necesario para JAXB)
    public Empleado() {
    }

    public Empleado(String Nombre, String PrimerApellido, String SegundoApellido, String PuestoDeTrabajo, int Sueldo, int Edad) {
        this.Nombre = Nombre;
        this.PrimerApellido = PrimerApellido;
        this.SegundoApellido = SegundoApellido;
        this.PuestoDeTrabajo = PuestoDeTrabajo;
        this.Sueldo = Sueldo;
        this.Edad = Edad;
    }

    @XmlElement(name = "Nombre")
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }

    @XmlElement(name = "PrimerApellido")
    public String getPrimerApellido() {
        return PrimerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.PrimerApellido = primerApellido;
    }

    @XmlElement(name = "SegundoApellido")
    public String getSegundoApellido() {
        return SegundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.SegundoApellido = segundoApellido;
    }

    @XmlElement(name = "PuestoDeTrabajo")
    public String getPuestoDeTrabajo() {
        return PuestoDeTrabajo;
    }

    public void setPuestoDeTrabajo(String puestoDeTrabajo) {
        this.PuestoDeTrabajo = puestoDeTrabajo;
    }

    @XmlElement(name = "Sueldo")
    public int getSueldo() {
        return Sueldo;
    }

    public void setSueldo(int sueldo) {
        this.Sueldo = sueldo;
    }

    @XmlElement(name = "Edad")
    public int getEdad() {
        return Edad;
    }

    public void setEdad(int edad) {
        this.Edad = edad;
    }

    @Override
    public String toString() {
        return "Empleado{"
                + "Nombre='" + Nombre + '\''
                + ", PrimerApellido='" + PrimerApellido + '\''
                + ", SegundoApellido='" + SegundoApellido + '\''
                + ", PuestoDeTrabajo='" + PuestoDeTrabajo + '\''
                + ", Sueldo=" + Sueldo
                + ", Edad=" + Edad
                + '}';
    }
}
