package com.ejemplo.maventaskade;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "empleados")
public class EmpleadoWrapper {

    private List<Empleado> empleados;

    public EmpleadoWrapper() {}

    public EmpleadoWrapper(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    @XmlElement(name = "empleado")
    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
}
